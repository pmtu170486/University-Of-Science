﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace QuanLySanPham
{
    class daoLoaiSP
    {
        Connection c = new Connection();
        SqlCommand comman;

        public DataTable LayThongTinLoaiSanPham()
        {
             c.OpenConnect();
            DataTable dt=new DataTable();
            comman = new SqlCommand("LayThongTinLoaiSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(comman);
            adapter.Fill(dt);
            
            c.CloseConnect();
            return dt;
        }

        public int ThemLoaiSanPham(dtoLoaiSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("ThemLoaiSanPham", c.Connect);

            comman.CommandType = System.Data.CommandType.StoredProcedure;

            comman.Parameters.Add("@MaLSP", System.Data.SqlDbType.NChar, 15).Value = lsp.MaLSP;
            comman.Parameters.Add("@TenLoai", System.Data.SqlDbType.NVarChar, 50).Value = lsp.TenLoai;
            int kq = (int)comman.ExecuteScalar();// nhận 0: thành công ; -1 thất bại do trùng khóa
            c.CloseConnect();
            return kq;

        }
        public int XoaLoaiSanPham(dtoLoaiSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_del_lsp", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaLSP", System.Data.SqlDbType.NChar, 15).Value = lsp.MaLSP;

            int kq = (int)comman.ExecuteScalar();
            c.CloseConnect();
            return kq;
        }
        public void CapNhatLoaiSanPham(dtoLoaiSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("CapNhatLoaiSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaLSP", System.Data.SqlDbType.NChar, 15).Value = lsp.MaLSP;
            comman.Parameters.Add("@TenLoai", System.Data.SqlDbType.NVarChar, 50).Value = lsp.TenLoai;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }
    }
}
