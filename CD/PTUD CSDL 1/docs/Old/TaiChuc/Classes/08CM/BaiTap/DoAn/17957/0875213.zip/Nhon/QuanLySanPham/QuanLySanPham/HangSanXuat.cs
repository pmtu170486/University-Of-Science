﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QuanLySanPham
{
    public partial class HangSanXuat : Form
    {
        public int Flag = -1;
        public HangSanXuat()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HangSanXuat_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
        private void HienThiQuocGia()
        {
            daoQuocGia daoqg = new daoQuocGia();
            cboMaQG.DataSource = daoqg.LayThongTinQuocGia();
            cboMaQG.DisplayMember = "Ten";
            cboMaQG.ValueMember = "MaQG";

        }

        private void LayDuLieuThongTinHangSanXuat()
        {
            daoHSX daohsx = new daoHSX();
            dgvHSX.DataSource = daohsx.LayThongTinHangSanXuat();
        }

        private void HangSanXuat_Load(object sender, EventArgs e)
        {
            daoQuocGia daoqg = new daoQuocGia();   
            cboMaQG.DataSource = daoqg.LayThongTinQuocGia();
            cboMaQG.DisplayMember = "Ten";
            cboMaQG.ValueMember = "MaQG";
            HienThiQuocGia();
            LayDuLieuThongTinHangSanXuat();
            khoaGird_danhsach(false);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {            
            if (txtMaHSX.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập mã hãng sản xuất !");
                txtMaHSX.Focus();
                return;
            }
          
            if (txtTenHSX.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập tên của hãng sản xuất !");
                txtTenHSX.Focus();
                return;
            }

            if (cboMaQG.SelectedValue == null)
            {
                MessageBox.Show("Yêu cầu chọn quốc gia của hãng sản xuất đang nhập liệu");
                cboMaQG.Focus();
                return;
            }

           
                dtoHSX dtohsx = new dtoHSX();
                dtohsx.MaHSX = txtMaHSX.Text;
                dtohsx.TenHSX = txtTenHSX.Text;
                dtohsx.MaQG = cboMaQG.SelectedValue.ToString();

            if (Flag == 1)
                {
                    daoHSX daohsx = new daoHSX();
                    int kq = daohsx.ThemHangSanXuat(dtohsx);
                    if (kq == -1)
                    { // thất bại, do trùng khóa chính;
                        MessageBox.Show("Trùng khóa chính rồi");
                        txtMaHSX.Focus();
                        return;
                    }
                } 
            else
                {
                    daoHSX daohsx = new daoHSX();
                    daohsx.CapNhatHangSanXuat(dtohsx);
                }   
            Flag = -1;
            daoHSX daoHSX = new daoHSX();
            dgvHSX.DataSource = daoHSX.LayThongTinHangSanXuat();
            dgvHSX.Enabled = true;
            khoaGird_danhsach(false);
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnCapNhat.Visible = true;
            btnXoa.Enabled = true;
            btnThoat.Enabled = true;

        }

        private void khoaGird_danhsach(bool p)
        {    
            txtMaHSX.Enabled = p;
            txtTenHSX.Enabled = p;
            cboMaQG.Enabled = p;
            btnThemQG.Enabled = p;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vitrixoa = dgvHSX.CurrentRow.Index;
                dtoHSX hsx = new dtoHSX();
                hsx.MaHSX = dgvHSX.Rows[vitrixoa].Cells[0].Value.ToString();
                daoHSX daohsx = new daoHSX();
                int kq=daohsx.XoaHangSanXuat(hsx);
                if (kq == 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    dgvHSX.DataSource = daohsx.LayThongTinHangSanXuat();
                }
                else
                {
                    MessageBox.Show("Lỗi trong quá trình thực hiện xóa dữ liệu, đề nghị kiểm tra lại!");
                }
                
            } 
        }

        private void btnThemQG_Click_1(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            qg.ShowDialog();
            HienThiQuocGia();
        }

        private void dgvHSX_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                int vitridong = dgvHSX.CurrentRow.Index;
                txtMaHSX.Text = dgvHSX.Rows[vitridong].Cells["mahsx"].Value.ToString().Trim();
                txtTenHSX.Text = dgvHSX.Rows[vitridong].Cells["tenhsx"].Value.ToString();
                cboMaQG.SelectedValue = dgvHSX.Rows[vitridong].Cells["maqg"].Value.ToString();
            }
            catch { }
        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnThoat.Enabled = true;
            btnCapNhat.Visible = true;

            if (dgvHSX.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }
            dgvHSX.Enabled = true;
            try
            {
                int vitridong = dgvHSX.CurrentRow.Index;
                txtMaHSX.Text = dgvHSX.Rows[vitridong].Cells["mahsx"].Value.ToString();
                txtTenHSX.Text = dgvHSX.Rows[vitridong].Cells["tenhsx"].Value.ToString();
                cboMaQG.SelectedValue = dgvHSX.Rows[vitridong].Cells["maqg"].Value.ToString();                
            }
            catch { }
            khoaGird_danhsach(false);
            Flag = -1;

      
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;

            dgvHSX.Enabled = false;

            txtMaHSX.Text = "";
            txtTenHSX.Text = "";
            cboMaQG.SelectedValue = -1;
            khoaGird_danhsach(true);
            Flag = 1;
            txtMaHSX.Focus();
        }

        private void btnCapNhat_Click_1(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;
            khoaGird_danhsach(true);
            Flag = 2;
            txtMaHSX.Focus();
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (dgvHSX.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }

            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vt = dgvHSX.CurrentRow.Index;
                dtoHSX hsx = new dtoHSX();
                hsx.MaHSX = dgvHSX.Rows[vt].Cells[0].Value.ToString();
                daoHSX daohsx = new daoHSX();

                int kq = daohsx.XoaHangSanXuat(hsx);
                if (kq == 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    dgvHSX.DataSource = daohsx.LayThongTinHangSanXuat();
 
                }
                else
                {
                    MessageBox.Show("Quá trình thực hiện xóa thất bại, đề nghị kiểm tra lại!");
                }
                
                
            }
        }

        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
       
    }
}
