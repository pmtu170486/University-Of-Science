﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace QLSP
{
    class LoaiSanPham
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public LoaiSanPham()
        {
            ID = 0;
            Name = "";
        }

        public DataTable LayDanhSach()
        {
            return DataProvider.ExecuteQuyery("SELECT * FROM LOAISANPHAM");
        }

        public void Xoa(int id)
        {
            DataProvider.ExecuteNonQuery("DELETE FROM LOAISANPHAM WHERE ID = " + id);
        }

        public void Them(string p)
        {
            DataProvider.ExecuteNonQuery("Insert into LOAISANPHAM(NAME) values('" + p + "')");
        }
    }
}
