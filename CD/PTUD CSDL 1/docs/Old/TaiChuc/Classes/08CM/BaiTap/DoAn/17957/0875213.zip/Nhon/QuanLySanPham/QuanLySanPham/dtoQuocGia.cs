﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuanLySanPham
{
    class dtoQuocGia
    {
        private string _maQG;

        public string MaQG
        {
            get { return _maQG; }
            set { _maQG = value; }
        }
        private string _Ten;

        public string Ten
        {
            get { return _Ten; }
            set { _Ten = value; }
        }
    }
}
