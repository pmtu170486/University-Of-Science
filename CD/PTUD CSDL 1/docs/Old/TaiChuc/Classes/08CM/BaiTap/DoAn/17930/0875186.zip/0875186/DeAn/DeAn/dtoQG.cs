﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeAn
{
   public class dtoQG
    {
        private string maQG;

        public string MaQG
        {
            get { return maQG; }
            set { maQG = value; }
        }
        private string ten;

        public string Ten
        {
            get { return ten; }
            set { ten = value; }
        }
    }
}
