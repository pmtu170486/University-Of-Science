﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeAn
{
    public partial class frQuocGia : Form
    {
        public frQuocGia()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            daoQG daoQG = new daoQG();
            dgvDSQG.DataSource = daoQG.LayThongTinQG();
        }

        private void dgvDSQG_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int vtd = dgvDSQG.CurrentRow.Index;
            txtMaQG.Text = dgvDSQG.Rows[vtd].Cells[0].Value.ToString();
            txtTenQG.Text = dgvDSQG.Rows[vtd].Cells[1].Value.ToString();

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoQG dtoQG = new dtoQG();
            dtoQG.MaQG = txtMaQG.Text;
            dtoQG.Ten = txtTenQG.Text;
            daoQG daoQG = new daoQG();
            daoQG.ThemQuocGia(dtoQG);
            MessageBox.Show("Thêm Quốc Gia Thành Công!");
            dgvDSQG.DataSource = daoQG.LayThongTinQG();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            dtoQG dtoQG = new dtoQG();
            dtoQG.MaQG = txtMaQG.Text;
            dtoQG.Ten = txtTenQG.Text;
            daoQG daoQG = new daoQG();
            daoQG.CapNhatQG(dtoQG);
            MessageBox.Show("Cập Nhật Quốc Gia Thành Công!");
            dgvDSQG.DataSource = daoQG.LayThongTinQG();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int vtd = dgvDSQG.CurrentRow.Index;
            dtoQG qg = new dtoQG();
            qg.MaQG = dgvDSQG.Rows[vtd].Cells[0].Value.ToString();
            daoQG daoQG = new daoQG();
            daoQG.XoaQuocGia(qg);
            MessageBox.Show("Đã Xóa Quốc Gia!");
            dgvDSQG.DataSource = daoQG.LayThongTinQG();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
