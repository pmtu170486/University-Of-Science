﻿namespace QuanLySanPham
{
    partial class HangSanXuat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnThemQG = new System.Windows.Forms.Button();
            this.cboMaQG = new System.Windows.Forms.ComboBox();
            this.txtTenHSX = new System.Windows.Forms.TextBox();
            this.txtMaHSX = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnboqua = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvHSX = new System.Windows.Forms.DataGridView();
            this.mahsx = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenhsx = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maqg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ten = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHSX)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnThemQG);
            this.groupBox1.Controls.Add(this.cboMaQG);
            this.groupBox1.Controls.Add(this.txtTenHSX);
            this.groupBox1.Controls.Add(this.txtMaHSX);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(19, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(406, 151);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin hãng sản xuất :";
            // 
            // btnThemQG
            // 
            this.btnThemQG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemQG.ForeColor = System.Drawing.Color.Black;
            this.btnThemQG.Location = new System.Drawing.Point(359, 91);
            this.btnThemQG.Name = "btnThemQG";
            this.btnThemQG.Size = new System.Drawing.Size(32, 22);
            this.btnThemQG.TabIndex = 12;
            this.btnThemQG.Text = "...";
            this.btnThemQG.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnThemQG.UseVisualStyleBackColor = true;
            this.btnThemQG.Click += new System.EventHandler(this.btnThemQG_Click_1);
            // 
            // cboMaQG
            // 
            this.cboMaQG.FormattingEnabled = true;
            this.cboMaQG.Location = new System.Drawing.Point(176, 92);
            this.cboMaQG.Name = "cboMaQG";
            this.cboMaQG.Size = new System.Drawing.Size(177, 21);
            this.cboMaQG.TabIndex = 11;
            // 
            // txtTenHSX
            // 
            this.txtTenHSX.Location = new System.Drawing.Point(176, 64);
            this.txtTenHSX.Name = "txtTenHSX";
            this.txtTenHSX.Size = new System.Drawing.Size(215, 20);
            this.txtTenHSX.TabIndex = 9;
            // 
            // txtMaHSX
            // 
            this.txtMaHSX.Location = new System.Drawing.Point(176, 37);
            this.txtMaHSX.Name = "txtMaHSX";
            this.txtMaHSX.Size = new System.Drawing.Size(108, 20);
            this.txtMaHSX.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(92, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Quốc gia :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tên hãng sản xuất :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Mã hãng sản xuất :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnboqua);
            this.groupBox2.Controls.Add(this.btnThoat);
            this.groupBox2.Controls.Add(this.btnLuu);
            this.groupBox2.Controls.Add(this.btnXoa);
            this.groupBox2.Controls.Add(this.btnCapNhat);
            this.groupBox2.Controls.Add(this.btnThem);
            this.groupBox2.Location = new System.Drawing.Point(17, 374);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(408, 53);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // btnboqua
            // 
            this.btnboqua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnboqua.Location = new System.Drawing.Point(111, 20);
            this.btnboqua.Name = "btnboqua";
            this.btnboqua.Size = new System.Drawing.Size(93, 23);
            this.btnboqua.TabIndex = 5;
            this.btnboqua.Text = "&Bỏ qua";
            this.btnboqua.UseVisualStyleBackColor = true;
            this.btnboqua.Visible = false;
            this.btnboqua.Click += new System.EventHandler(this.btnboqua_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Location = new System.Drawing.Point(299, 20);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(93, 23);
            this.btnThoat.TabIndex = 3;
            this.btnThoat.Text = "&Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click_1);
            // 
            // btnLuu
            // 
            this.btnLuu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuu.Location = new System.Drawing.Point(16, 20);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(93, 23);
            this.btnLuu.TabIndex = 4;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Visible = false;
            this.btnLuu.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoa.Location = new System.Drawing.Point(205, 20);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(93, 23);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click_1);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapNhat.Location = new System.Drawing.Point(111, 20);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(93, 23);
            this.btnCapNhat.TabIndex = 1;
            this.btnCapNhat.Text = "&Cập nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click_1);
            // 
            // btnThem
            // 
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Location = new System.Drawing.Point(16, 20);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(93, 23);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "&Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvHSX);
            this.groupBox3.Location = new System.Drawing.Point(19, 162);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(406, 210);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách hãng sản xuất :";
            // 
            // dgvHSX
            // 
            this.dgvHSX.AllowUserToAddRows = false;
            this.dgvHSX.AllowUserToDeleteRows = false;
            this.dgvHSX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHSX.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mahsx,
            this.tenhsx,
            this.maqg,
            this.ten});
            this.dgvHSX.Location = new System.Drawing.Point(33, 18);
            this.dgvHSX.Name = "dgvHSX";
            this.dgvHSX.Size = new System.Drawing.Size(343, 182);
            this.dgvHSX.TabIndex = 5;
            this.dgvHSX.CurrentCellChanged += new System.EventHandler(this.dgvHSX_CurrentCellChanged);
            // 
            // mahsx
            // 
            this.mahsx.DataPropertyName = "mahsx";
            this.mahsx.HeaderText = "Mã hãng sản xuất";
            this.mahsx.Name = "mahsx";
            // 
            // tenhsx
            // 
            this.tenhsx.DataPropertyName = "tenhsx";
            this.tenhsx.HeaderText = "Tên hãng sản xuất";
            this.tenhsx.Name = "tenhsx";
            // 
            // maqg
            // 
            this.maqg.DataPropertyName = "maqg";
            this.maqg.HeaderText = "maqg";
            this.maqg.Name = "maqg";
            this.maqg.Visible = false;
            // 
            // ten
            // 
            this.ten.DataPropertyName = "ten";
            this.ten.HeaderText = "Quốc gia";
            this.ten.Name = "ten";
            // 
            // HangSanXuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(442, 433);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HangSanXuat";
            this.Text = "Quản lý hãng sản xuất";
            this.Load += new System.EventHandler(this.HangSanXuat_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HangSanXuat_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHSX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboMaQG;
        private System.Windows.Forms.TextBox txtTenHSX;
        private System.Windows.Forms.TextBox txtMaHSX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnThemQG;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnboqua;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvHSX;
        private System.Windows.Forms.DataGridViewTextBoxColumn mahsx;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenhsx;
        private System.Windows.Forms.DataGridViewTextBoxColumn maqg;
        private System.Windows.Forms.DataGridViewTextBoxColumn ten;
    }
}