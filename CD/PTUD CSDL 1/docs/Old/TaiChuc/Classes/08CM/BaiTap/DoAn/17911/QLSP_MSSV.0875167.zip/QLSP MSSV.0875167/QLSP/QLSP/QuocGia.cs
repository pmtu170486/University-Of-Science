﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace QLSP
{
    class QuocGia
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public QuocGia()
        {
            ID = 0;
            Name = "";
        }

        public DataTable LayDanhSach()
        {
            return DataProvider.ExecuteQuyery("SELECT * FROM QUOCGIA");
        }

        public void Xoa(int id)
        {
            DataProvider.ExecuteNonQuery("DELETE FROM QUOCGIA WHERE ID = " + id);
        }

        internal void Them(string p)
        {
            DataProvider.ExecuteNonQuery("Insert into QUOCGIA(NAME) values('" + p + "')");
        }
    }


}
