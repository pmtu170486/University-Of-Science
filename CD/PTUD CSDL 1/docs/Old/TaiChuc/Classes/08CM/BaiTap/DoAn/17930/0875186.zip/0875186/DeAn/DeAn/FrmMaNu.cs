﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeAn
{
    public partial class FrmMaNu : Form
    {
        public FrmMaNu()
        {
            InitializeComponent();
        }

        private void quảnLýSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frSanPham frm = new frSanPham();
            frm.MdiParent = this;
            frm.Show();

        }

        private void quảnLýLoạiSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frLoaiSanPham frmL = new frLoaiSanPham();
            frmL.MdiParent = this;
            frmL.Show();

        }

        private void quảnLýHãngSảnXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frHangSanXuat frmH = new frHangSanXuat();
            frmH.MdiParent = this;
            frmH.Show();
        }

        private void quảnLýQuốcGiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frQuocGia frmQ = new frQuocGia();
            frmQ.MdiParent = this;
            frmQ.Show();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thoátToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thoátToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinNhómToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmThongTinNhom FRMN = new FrmThongTinNhom();
            FRMN.MdiParent = this;
            FRMN.Show();
        }

        private void thôngTinBảnQuyềnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmBanQuyen frm = new FrmBanQuyen();
            frm.MdiParent = this;
            frm.Show();
        }

        private void hỗTrợTrựcTuyếnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmTroGiup frm = new FrmTroGiup();
            frm.MdiParent = this;
            frm.Show();

        }

        private void FrmMaNu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Cãm Ơn Bạn Đã Sử Dụng Phần Mềm Của Nhóm Chúng Tôi.Bạn Có Muốn Đóng Chương Trình ?",
               "Thông Báo Dành Cho Người Dùng", MessageBoxButtons.YesNo)
               == DialogResult.No)
            {
                e.Cancel = true;
            
            }
        }
    }
}
