﻿namespace QuanLySanPham
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnQG = new System.Windows.Forms.Button();
            this.btnLSP = new System.Windows.Forms.Button();
            this.btnHSX = new System.Windows.Forms.Button();
            this.btnSP = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(309, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 72);
            this.label2.TabIndex = 7;
            this.label2.Text = "Quản Lý Sản Phẩm";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(340, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 65);
            this.label1.TabIndex = 6;
            this.label1.Text = "Phần Mềm";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackgroundImage = global::QuanLySanPham.Properties.Resources._15;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.Black;
            this.btnThoat.Location = new System.Drawing.Point(767, 123);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(212, 31);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnQG
            // 
            this.btnQG.BackgroundImage = global::QuanLySanPham.Properties.Resources._15;
            this.btnQG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQG.ForeColor = System.Drawing.Color.Black;
            this.btnQG.Location = new System.Drawing.Point(767, 93);
            this.btnQG.Name = "btnQG";
            this.btnQG.Size = new System.Drawing.Size(212, 31);
            this.btnQG.TabIndex = 4;
            this.btnQG.Text = "Quản lý quốc gia";
            this.btnQG.UseVisualStyleBackColor = true;
            this.btnQG.Click += new System.EventHandler(this.btnQG_Click_1);
            // 
            // btnLSP
            // 
            this.btnLSP.BackgroundImage = global::QuanLySanPham.Properties.Resources._13;
            this.btnLSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLSP.ForeColor = System.Drawing.Color.Black;
            this.btnLSP.Location = new System.Drawing.Point(767, 63);
            this.btnLSP.Name = "btnLSP";
            this.btnLSP.Size = new System.Drawing.Size(212, 31);
            this.btnLSP.TabIndex = 3;
            this.btnLSP.Text = "Quản lý loại sản phẩm";
            this.btnLSP.UseVisualStyleBackColor = true;
            this.btnLSP.Click += new System.EventHandler(this.btnLSP_Click_1);
            // 
            // btnHSX
            // 
            this.btnHSX.BackgroundImage = global::QuanLySanPham.Properties.Resources._1111111111111;
            this.btnHSX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHSX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHSX.ForeColor = System.Drawing.Color.Black;
            this.btnHSX.Location = new System.Drawing.Point(767, 33);
            this.btnHSX.Name = "btnHSX";
            this.btnHSX.Size = new System.Drawing.Size(212, 31);
            this.btnHSX.TabIndex = 2;
            this.btnHSX.Text = "Quản lý hãng sản xuất";
            this.btnHSX.UseVisualStyleBackColor = true;
            this.btnHSX.Click += new System.EventHandler(this.btnHSX_Click_1);
            // 
            // btnSP
            // 
            this.btnSP.BackgroundImage = global::QuanLySanPham.Properties.Resources._12;
            this.btnSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSP.ForeColor = System.Drawing.Color.Black;
            this.btnSP.Location = new System.Drawing.Point(767, 3);
            this.btnSP.Name = "btnSP";
            this.btnSP.Size = new System.Drawing.Size(212, 31);
            this.btnSP.TabIndex = 1;
            this.btnSP.Text = "Quản lý sản phẩm";
            this.btnSP.UseVisualStyleBackColor = true;
            this.btnSP.Click += new System.EventHandler(this.btnSP_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Image = global::QuanLySanPham.Properties.Resources._444444444;
            this.label4.Location = new System.Drawing.Point(653, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(299, 39);
            this.label4.TabIndex = 15;
            this.label4.Text = "Danh Sách Nhóm:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Image = global::QuanLySanPham.Properties.Resources._10101010;
            this.label6.Location = new System.Drawing.Point(646, 454);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(225, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "4. Trần Thị Diễm_0875120 ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Image = global::QuanLySanPham.Properties.Resources._99999999;
            this.label9.Location = new System.Drawing.Point(646, 434);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(259, 20);
            this.label9.TabIndex = 20;
            this.label9.Text = "3. Đặng Huyền Trang_0875261";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Image = global::QuanLySanPham.Properties.Resources._88888;
            this.label10.Location = new System.Drawing.Point(646, 414);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(306, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "2. Trần Mạch Yến Phương _ 0875223";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Image = global::QuanLySanPham.Properties.Resources._55555555555;
            this.label11.Location = new System.Drawing.Point(646, 394);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(244, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "1. Trương Quí Nhơn_0875213";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Image = global::QuanLySanPham.Properties.Resources._2222222;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 47);
            this.label3.TabIndex = 23;
            this.label3.Text = "Nhóm Kết Nối";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::QuanLySanPham.Properties.Resources.alo;
            this.ClientSize = new System.Drawing.Size(980, 554);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnQG);
            this.Controls.Add(this.btnLSP);
            this.Controls.Add(this.btnHSX);
            this.Controls.Add(this.btnSP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Red;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sản Phẩm";
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnQG;
        private System.Windows.Forms.Button btnLSP;
        private System.Windows.Forms.Button btnHSX;
        private System.Windows.Forms.Button btnSP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;


    }
}

