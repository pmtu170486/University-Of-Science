﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeAn
{
    public partial class frHangSanXuat : Form
    {
        public frHangSanXuat()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            daoQG daoQG = new daoQG();
            cbQG.DataSource = daoQG.LayThongTinQG();
            cbQG.DisplayMember = "Ten";
            cbQG.ValueMember = "MaQG";

            daoHSX daoHSX = new daoHSX();
            dgvDSHSX.DataSource = daoHSX.LayThongTinHSX();
            
        }

        private void dgvDSHSX_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int vtd = dgvDSHSX.CurrentRow.Index;
            txtMaHSX.Text = dgvDSHSX.Rows[vtd].Cells[0].Value.ToString();
            txtTenHSX.Text = dgvDSHSX.Rows[vtd].Cells[1].Value.ToString();
            cbQG.SelectedValue = dgvDSHSX.Rows[vtd].Cells[2].Value.ToString();
            
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoHSX dtoHSX = new dtoHSX();
            dtoHSX.MaHSX = txtMaHSX.Text;
            dtoHSX.TenHSX = txtTenHSX.Text;
            dtoHSX.MaQG = (string)cbQG.SelectedValue;
            daoHSX daoHSX = new daoHSX();
            daoHSX.ThemHangSanXuat(dtoHSX);
            MessageBox.Show("Thêm Hãng Sản Xuất Thành Công!");
            dgvDSHSX.DataSource = daoHSX.LayThongTinHSX();

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            dtoHSX dtoHSX = new dtoHSX();
            dtoHSX.MaHSX = txtMaHSX.Text;
            dtoHSX.TenHSX = txtTenHSX.Text;
            dtoHSX.MaQG = (string)cbQG.SelectedValue;
            daoHSX daoHSX = new daoHSX();
            daoHSX.CapNhatHSX(dtoHSX);
            MessageBox.Show("Cập Nhật Hãng Sản Xuất Thành Công!");
            dgvDSHSX.DataSource = daoHSX.LayThongTinHSX();

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int vtd = dgvDSHSX.CurrentRow.Index;
            dtoHSX hsx = new dtoHSX();
            hsx.MaHSX = dgvDSHSX.Rows[vtd].Cells[0].Value.ToString();
            daoHSX daoHSX = new daoHSX();
            daoHSX.XoaHangSanXuat(hsx);
            MessageBox.Show("Đã Xóa Hãng Sản Xuất!");
            dgvDSHSX.DataSource = daoHSX.LayThongTinHSX();
            
        }

        private void btnThemQG_Click(object sender, EventArgs e)
        {
            frQuocGia fr = new frQuocGia();
            fr.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }



        

    }
}
