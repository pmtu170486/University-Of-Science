﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeAn
{
    public partial class frSanPham : Form
    {
        public frSanPham()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            daoHSX daoHSX = new daoHSX();
            cbHangSX.DataSource = daoHSX.LayThongTinHSX();
            cbHangSX.ValueMember = "MaHSX";
            cbHangSX.DisplayMember = "TenHSX";

            daoLSP daoLSP = new daoLSP();
            cbLoaiSP.DataSource = daoLSP.LayThongTinLoaiSP();
            cbLoaiSP.DisplayMember = "TenLoai";
            cbLoaiSP.ValueMember = "MaLSP";

            daoSanPham daoSP = new daoSanPham();
            dgvDSSP.DataSource = daoSP.XemDanhSachSanPham();
        }

        private void dgvDSSP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            int vtd = dgvDSSP.CurrentRow.Index;
            txtMaSP.Text = dgvDSSP.Rows[vtd].Cells[0].Value.ToString();
            txtTenSP.Text = dgvDSSP.Rows[vtd].Cells[1].Value.ToString();
            txtMoTa.Text = dgvDSSP.Rows[vtd].Cells[2].Value.ToString();
            txtSeRi.Text = dgvDSSP.Rows[vtd].Cells[3].Value.ToString();
            cbHangSX.SelectedValue = dgvDSSP.Rows[vtd].Cells[4].Value.ToString();
            cbLoaiSP.SelectedValue = dgvDSSP.Rows[vtd].Cells[5].Value.ToString();

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoSanPham dtoSP = new dtoSanPham();
            dtoSP.MaSP = txtMaSP.Text;
            dtoSP.TenSP = txtTenSP.Text;
            dtoSP.MoTa = txtMoTa.Text;
            dtoSP.SeRi = txtSeRi.Text;
            dtoSP.MaHSX = (string)cbHangSX.SelectedValue;
            dtoSP.LoaiSP = (string)cbLoaiSP.SelectedValue;
            daoSanPham daoSP = new daoSanPham();
            daoSP.ThemSanPham(dtoSP);
            MessageBox.Show("Thêm Sản Phẩm Thành Công!");
            dgvDSSP.DataSource = daoSP.XemDanhSachSanPham();
        
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            dtoSanPham dtoSP = new dtoSanPham();
            dtoSP.MaSP = txtMaSP.Text;
            dtoSP.TenSP = txtTenSP.Text;
            dtoSP.MoTa = txtMoTa.Text;
            dtoSP.SeRi = txtSeRi.Text;
            dtoSP.MaHSX = (string)cbHangSX.SelectedValue;
            dtoSP.LoaiSP = (string)cbLoaiSP.SelectedValue;
            daoSanPham daoSP = new daoSanPham();
            daoSP.CapNhatSanPham(dtoSP);
            MessageBox.Show("Cập Nhật Thành Công!");
            dgvDSSP.DataSource = daoSP.XemDanhSachSanPham();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int vtd = dgvDSSP.CurrentRow.Index;
            dtoSanPham sp = new dtoSanPham();
            sp.MaSP = dgvDSSP.Rows[vtd].Cells[0].Value.ToString();
            daoSanPham daoSP = new daoSanPham();
            daoSP.XoaSanPham(sp);
            MessageBox.Show("Đã Xóa Sản Phẩm!");
            dgvDSSP.DataSource = daoSP.XemDanhSachSanPham();
            
        }

        private void btnThemHSX_Click(object sender, EventArgs e)
        {
            frHangSanXuat fr = new frHangSanXuat();
            fr.ShowDialog();
        }

        private void ThemLSP_Click(object sender, EventArgs e)
        {
            frLoaiSanPham fr = new frLoaiSanPham();
            fr.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

    }
}
