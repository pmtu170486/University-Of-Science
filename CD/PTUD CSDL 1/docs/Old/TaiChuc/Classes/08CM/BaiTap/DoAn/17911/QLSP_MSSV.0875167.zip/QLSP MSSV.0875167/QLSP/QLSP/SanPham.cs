﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace QLSP
{
    class SanPham
    {

        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public SanPham()
        {
            ID = 0;
            Name = "";
        }

        public DataTable LayDanhSach()
        {
            return DataProvider.ExecuteQuyery("SELECT * FROM SANPHAM");
        }

        public void Xoa(int id)
        {
            DataProvider.ExecuteNonQuery("DELETE FROM SANPHAM WHERE ID = " + id);
        }

        public void Them(string p,string mota,string seri,int idhsp, int idlsp)
        {
            DataProvider.ExecuteNonQuery("Insert into SANPHAM(NAME,MOTA,SERI,IDHANGSANPHAM,IDLOAISANPHAM) values('" + p + "','"+mota+"','"+seri+"',"+idhsp+"," + idlsp + ")");
        }
    }
}
