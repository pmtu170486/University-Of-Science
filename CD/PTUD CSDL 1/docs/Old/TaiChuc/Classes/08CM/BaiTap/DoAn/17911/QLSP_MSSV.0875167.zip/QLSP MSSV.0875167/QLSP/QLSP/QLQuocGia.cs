﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace QLSP
{
    public partial class QLQuocGia : Form
    {
        public QLQuocGia()
        {
            InitializeComponent();
        }



        private void QLQuocGia_Load(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            dgvDSQG.DataSource = qg.LayDanhSach();
        }

        private void btnCapNhatQuocGia_Click(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            dgvDSQG.DataSource = qg.LayDanhSach();
            MessageBox.Show("Cap Nhat Thành Công");
        }

        private void btnXoaQuocGia_Click(object sender, EventArgs e)
        {
            if (dgvDSQG.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvDSQG.SelectedRows[0];
                if (!row.IsNewRow)
                {
                    int id = Convert.ToInt32(row.Cells[0].Value);
                    string thongbao = "ban co muon xoa  " + id;
                    if (MessageBox.Show(
                        thongbao,
                        "XacNhan",
                        MessageBoxButtons.YesNo
                        ) ==
                        DialogResult.Yes)
                    {
                        QuocGia qg = new QuocGia();
                        qg.Xoa(id);
                        dgvDSQG.DataSource = qg.LayDanhSach();
                    }
                }
            }
        }

        private void btnThemQuocGia_Click(object sender, EventArgs e)
        {

            if (txtTenQG.Text == "")
            {
                MessageBox.Show("Nhập tên Quốc gia");
                return;
            }
            QuocGia qg = new QuocGia();
            qg.Them(txtTenQG.Text);

            dgvDSQG.DataSource = qg.LayDanhSach();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
