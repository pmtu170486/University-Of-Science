﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace QuanLySanPham
{
    class daoSanPham
    {
     Connection c = new Connection();
     SqlCommand comman;
        public int ThemSanPham(dtoSanPham sp)
        {
            c.OpenConnect();
            comman = new SqlCommand("ThemSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaSP", System.Data.SqlDbType.NChar, 15).Value = sp.MaSP;
            comman.Parameters.Add("@TenSP", System.Data.SqlDbType.NVarChar, 50).Value = sp.TenSP;
            comman.Parameters.Add("@MoTa", System.Data.SqlDbType.NVarChar, 50).Value = sp.MoTa;
            comman.Parameters.Add("@Seri", System.Data.SqlDbType.Char, 20).Value = sp.Seri;
            comman.Parameters.Add("@MaHSX", System.Data.SqlDbType.NChar, 15).Value = sp.MaHSX;
            comman.Parameters.Add("@MaLSP", System.Data.SqlDbType.NChar, 15).Value = sp.MaLSP;

            int KQ = (int)comman.ExecuteNonQuery();
            c.CloseConnect();
            return KQ;

        }
        public DataTable LayThongTinSanPham()
        {   
            c.OpenConnect();
            DataTable dt=new DataTable();
            comman = new SqlCommand("LayThongTinSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(comman);
            adapter.Fill(dt);
            
            c.CloseConnect();
            return dt;

        }

        public void XoaSanPham(dtoSanPham sp)
        {
            c.OpenConnect();
            comman = new SqlCommand("XoaSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaSP", System.Data.SqlDbType.NChar,15).Value = sp.MaSP;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }
        public void CapNhatSanPham(dtoSanPham sp)
        {
            c.OpenConnect();
            comman = new SqlCommand("CapNhatSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@TenSP", System.Data.SqlDbType.NVarChar,50 ).Value = sp.TenSP;
            comman.Parameters.Add("@MoTa", System.Data.SqlDbType.NVarChar, 50).Value = sp.MoTa;
            comman.Parameters.Add("@Seri", System.Data.SqlDbType.Char, 20).Value = sp.Seri;
            comman.Parameters.Add("@MaHSX", System.Data.SqlDbType.NChar, 15).Value = sp.MaHSX;
            comman.Parameters.Add("@MaLSP", System.Data.SqlDbType.NChar,15).Value = sp.MaLSP;
            comman.Parameters.Add("@MaSP", System.Data.SqlDbType.NChar, 15).Value = sp.MaSP;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }



   
    }
}
