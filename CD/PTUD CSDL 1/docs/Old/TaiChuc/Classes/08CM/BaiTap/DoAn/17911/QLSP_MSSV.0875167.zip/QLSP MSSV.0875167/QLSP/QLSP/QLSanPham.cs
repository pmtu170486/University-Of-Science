﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace QLSP
{
    public partial class QLSanPham : Form
    {
        public QLSanPham()
        {
            InitializeComponent();
        }


        private void btnThemSanPham_Click(object sender, EventArgs e)
        {
            if (txtTenSP.Text == "")
            {
                MessageBox.Show("Nhập tên Sản Phẩm");
                return;
            }

            SanPham sp = new SanPham();
            sp.Them(txtTenSP.Text, txtMoTa.Text, txtSeri.Text, (int)cbx_HSP.SelectedValue, (int)cbx_LSP.SelectedValue);

            btnCapNhat_Click(sender, e);
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDSSP.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvDSSP.SelectedRows[0];
                if (!row.IsNewRow)
                {
                    int id = Convert.ToInt32(row.Cells[0].Value);
                    string thongbao = "ban co muon xoa  " + id;
                    if (MessageBox.Show(
                        thongbao,
                        "XacNhan",
                        MessageBoxButtons.YesNo
                        ) ==
                        DialogResult.Yes)
                    {
                        SanPham qg = new SanPham();
                        qg.Xoa(id);
                        dgvDSSP.DataSource = qg.LayDanhSach();

                    }
                }
            }
        }
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            HangSanPham h = new HangSanPham();
            cbx_HSP.DataSource = h.LayDanhSach();
            cbx_HSP.DisplayMember = "NAME";
            cbx_HSP.ValueMember = "ID";

            LoaiSanPham l = new LoaiSanPham();
            cbx_LSP.DataSource = l.LayDanhSach();
            cbx_LSP.DisplayMember = "NAME";
            cbx_LSP.ValueMember = "ID";

            SanPham sp = new SanPham();
            dgvDSSP.DataSource = sp.LayDanhSach();
            MessageBox.Show("Cap Nhat Thành Công");
        }
        private void QuanLySanPham_Load(object sender, EventArgs e)
        {
            HangSanPham h = new HangSanPham();
            cbx_HSP.DataSource = h.LayDanhSach();
            cbx_HSP.DisplayMember = "NAME";
            cbx_HSP.ValueMember = "ID";

            LoaiSanPham l = new LoaiSanPham();
            cbx_LSP.DataSource = l.LayDanhSach();
            cbx_LSP.DisplayMember = "NAME";
            cbx_LSP.ValueMember = "ID";

            SanPham sp = new SanPham();
            dgvDSSP.DataSource = sp.LayDanhSach();
        }

        private void txtMaSP_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
