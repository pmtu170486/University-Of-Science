﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace QLSP
{
    public partial class QLHangSanXuat : Form
    {
        public QLHangSanXuat()
        {
            InitializeComponent();
        }

        private void QLHangSanXuat_Load(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            cbx_QuocGia.DataSource = qg.LayDanhSach();
            cbx_QuocGia.DisplayMember = "NAME";
            cbx_QuocGia.ValueMember = "ID";

            HangSanPham hsp = new HangSanPham();
            dgvDSHSX.DataSource = hsp.LayDanhSach();

        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            cbx_QuocGia.DataSource = qg.LayDanhSach();
            cbx_QuocGia.DisplayMember = "NAME";
            cbx_QuocGia.ValueMember = "ID";

            HangSanPham hsp = new HangSanPham();
            dgvDSHSX.DataSource = hsp.LayDanhSach();
            MessageBox.Show("Cap Nhat Thành Công");
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDSHSX.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvDSHSX.SelectedRows[0];
                if (!row.IsNewRow)
                {
                    int id = Convert.ToInt32(row.Cells[0].Value);
                    string thongbao = "ban co muon xoa  " + id;
                    if (MessageBox.Show(
                        thongbao,
                        "XacNhan",
                        MessageBoxButtons.YesNo
                        ) ==
                        DialogResult.Yes)
                    {
                        HangSanPham qg = new HangSanPham();
                        qg.Xoa(id);
                        dgvDSHSX.DataSource = qg.LayDanhSach();

                    }
                }
            }
        }

        private void btnThemHangSanXuat_Click(object sender, EventArgs e)
        {
            if (txtTenHSX.Text == "")
            {
                MessageBox.Show("Nhập tên Hảng Sản Phẩm");
                return;
            }


            HangSanPham qg = new HangSanPham();
            qg.Them(txtTenHSX.Text,(int)cbx_QuocGia.SelectedValue);

            dgvDSHSX.DataSource = qg.LayDanhSach();
        }
    }
}
