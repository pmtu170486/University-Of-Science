﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace DeAn
{
    public class daoHSX
    {
        connection c = new connection();
        SqlCommand comman;
        public List<dtoHSX> LayThongTinHSX()
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_laythongtinhangsanxuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = comman.ExecuteReader();
            List<dtoHSX> List = new List<dtoHSX>();
            dtoHSX l;
            while (reader.Read())
            {
                l = new dtoHSX();
                l.MaHSX = reader["MaHSX"].ToString();
                l.TenHSX = reader["TenHSX"].ToString();
                l.MaQG = reader["MaQG"].ToString();
                List.Add(l);
            }
            c.CloseConnect();
            return List;

        }
        public void ThemHangSanXuat(dtoHSX hsx)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_themHangSanXuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maHSX", System.Data.SqlDbType.NChar, 100).Value = hsx.MaHSX;
            comman.Parameters.Add("@tenHSX", System.Data.SqlDbType.NVarChar, 100).Value = hsx.TenHSX;
            comman.Parameters.Add("@maQG", System.Data.SqlDbType.NChar, 100).Value = hsx.MaQG;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }

        public void CapNhatHSX(dtoHSX hsx)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_capnhatHangSanXuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maHSX", System.Data.SqlDbType.NChar, 100).Value = hsx.MaHSX;
            comman.Parameters.Add("@tenHSX", System.Data.SqlDbType.NVarChar, 100).Value = hsx.TenHSX;
            comman.Parameters.Add("@maQG", System.Data.SqlDbType.NChar, 100).Value = hsx.MaQG;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }

        public void XoaHangSanXuat(dtoHSX hsx)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_xoaHangSanXuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maHSX", System.Data.SqlDbType.NChar, 100).Value = hsx.MaHSX;
            comman.ExecuteNonQuery();
            c.CloseConnect();

        }
    }
}
