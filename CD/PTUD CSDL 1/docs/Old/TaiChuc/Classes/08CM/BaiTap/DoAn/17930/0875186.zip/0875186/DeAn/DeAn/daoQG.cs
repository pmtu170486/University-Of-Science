﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace DeAn
{
   public class daoQG
    {
        connection c = new connection();
        SqlCommand comman;

        public List<dtoQG> LayThongTinQG()
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_laythongtinQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = comman.ExecuteReader();
            List<dtoQG> List = new List<dtoQG>();
            dtoQG l;
            while (reader.Read())
            {
                l = new dtoQG();
                l.MaQG = reader["MaQG"].ToString();
                l.Ten = reader["Ten"].ToString();
                List.Add(l);
            }
            c.CloseConnect();
            return List;

        }

        public void ThemQuocGia(dtoQG qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_themQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maQG", System.Data.SqlDbType.NChar, 100).Value = qg.MaQG;
            comman.Parameters.Add("@tenQG", System.Data.SqlDbType.NVarChar, 100).Value = qg.Ten;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }


        public void XoaQuocGia(dtoQG qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_xoaQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maQG", System.Data.SqlDbType.NChar, 100).Value = qg.MaQG;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }


        public void CapNhatQG(dtoQG qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_capnhatQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maQG", System.Data.SqlDbType.NChar, 100).Value = qg.MaQG;
            comman.Parameters.Add("@tenQG", System.Data.SqlDbType.NVarChar, 100).Value = qg.Ten;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }


    }
    
}
