﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeAn
{
   public class dtoHSX
    {
        private string maHSX;

        public string MaHSX
        {
            get { return maHSX; }
            set { maHSX = value; }
        }
        private string tenHSX;

        public string TenHSX
        {
            get { return tenHSX; }
            set { tenHSX = value; }
        }
        private string maQG;

        public string MaQG
        {
            get { return maQG; }
            set { maQG = value; }
        }
    }
}
