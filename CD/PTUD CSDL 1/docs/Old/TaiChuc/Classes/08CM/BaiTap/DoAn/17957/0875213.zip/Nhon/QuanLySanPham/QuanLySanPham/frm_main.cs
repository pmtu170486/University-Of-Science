﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QuanLySanPham
{
    public partial class frm_main : Form
    {
        public frm_main()
        {
            InitializeComponent();
        }      
            
               


        private void btnSP_Click_1(object sender, EventArgs e)
        {
            SanPham sp = new SanPham();

            sp.ShowDialog();
        }

        private void btnHSX_Click_1(object sender, EventArgs e)
        {
            HangSanXuat hsx = new HangSanXuat();
            hsx.ShowDialog();
        }

        private void btnLSP_Click_1(object sender, EventArgs e)
        {
            LoaiSanPham lsp = new LoaiSanPham();
            lsp.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void btnQG_Click_1(object sender, EventArgs e)
        {
            QuocGia qg = new QuocGia();
            qg.ShowDialog();
        }

        private void frm_main_Load(object sender, EventArgs e)
        {
            label1.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

          

        
    }
}
