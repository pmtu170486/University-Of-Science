﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QuanLySanPham
{
    public partial class LoaiSanPham : Form
    {
        public int Flag = -1;
        public LoaiSanPham()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoLoaiSP dtolsp = new dtoLoaiSP();
            dtolsp.MaLSP = txtMaLSP.Text;
            dtolsp.TenLoai = txtTenLSP.Text;
            daoLoaiSP daolsp = new daoLoaiSP();
            daolsp.ThemLoaiSanPham(dtolsp);
            MessageBox.Show("Thêm loại sản phẩm thành công !");
            LayThongTinLoaiSanPham();
           
        }

       
        private void LayThongTinLoaiSanPham()
        {
            daoLoaiSP daolsp = new daoLoaiSP();
            dgvLoaiSP.DataSource = daolsp.LayThongTinLoaiSanPham();
        }

        private void LoaiSanPham_Load(object sender, EventArgs e)
        {
            LayThongTinLoaiSanPham();
            khoaGird_danhsach(false);
        }

        private void khoaGird_danhsach(bool p)
        {
            txtMaLSP.Enabled = p;
            txtTenLSP.Enabled = p;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vitrixoa = dgvLoaiSP.CurrentRow.Index;
                dtoLoaiSP lsp = new dtoLoaiSP();
                lsp.MaLSP = dgvLoaiSP.Rows[vitrixoa].Cells[0].Value.ToString();
                daoLoaiSP daolsp = new daoLoaiSP();
                daolsp.XoaLoaiSanPham(lsp);
                MessageBox.Show("Xóa thành công!");
                dgvLoaiSP.DataSource = daolsp.LayThongTinLoaiSanPham();
            } 
            
            
        }

        private void dgvLoaiSP_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                int vitridong = dgvLoaiSP.CurrentRow.Index;
                txtMaLSP.Text = dgvLoaiSP.Rows[vitridong].Cells["malsp"].Value.ToString().Trim();
                txtTenLSP.Text = dgvLoaiSP.Rows[vitridong].Cells["tenloai"].Value.ToString();
            }
            catch { }
        }

        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaLSP.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập mã loại sản phẩm !");
                txtMaLSP.Focus();
                return;
            }

            if (txtTenLSP.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập tên của loại sản phẩm !");
                txtTenLSP.Focus();
                return;
            }
            
            dtoLoaiSP dtolsp = new dtoLoaiSP();
            dtolsp.MaLSP = txtMaLSP.Text;
            dtolsp.TenLoai = txtTenLSP.Text;
            
            if (Flag == 1)
            {
                daoLoaiSP daolsp = new daoLoaiSP();
                int kq = daolsp.ThemLoaiSanPham(dtolsp);
                if (kq == -1)
                { // thất bại, do trùng khóa chính;
                    MessageBox.Show("Trùng khóa chính rồi");
                    txtMaLSP.Focus();
                    return;
                }
            }
            else
            {
                daoLoaiSP daolsp = new daoLoaiSP();
                daolsp.CapNhatLoaiSanPham(dtolsp);
            }
            Flag = -1;
            daoLoaiSP daoLSP = new daoLoaiSP();
            dgvLoaiSP.DataSource = daoLSP.LayThongTinLoaiSanPham();
            dgvLoaiSP.Enabled = true;
            khoaGird_danhsach(false);
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnCapNhat.Visible = true;
            btnXoa.Enabled = true;
            btnThoat.Enabled = true;

        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnThoat.Enabled = true;
            btnCapNhat.Visible = true;

            if (dgvLoaiSP.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }
            dgvLoaiSP.Enabled = true;
            try
            {
                int vitridong = dgvLoaiSP.CurrentRow.Index;
                txtMaLSP.Text = dgvLoaiSP.Rows[vitridong].Cells["malsp"].Value.ToString();
                txtTenLSP.Text = dgvLoaiSP.Rows[vitridong].Cells["tenloai"].Value.ToString();
            }
            catch { }
            khoaGird_danhsach(false);
            Flag = -1;

        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;

            dgvLoaiSP.Enabled = false;

            txtMaLSP.Text = "";
            txtTenLSP.Text = "";
            khoaGird_danhsach(true);
            Flag = 1;
            txtMaLSP.Focus();
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;
            khoaGird_danhsach(true);
            Flag = 2;
            txtMaLSP.Focus();
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (dgvLoaiSP.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }

            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vt = dgvLoaiSP.CurrentRow.Index;
                dtoLoaiSP lsp = new dtoLoaiSP();
                lsp.MaLSP = dgvLoaiSP.Rows[vt].Cells[0].Value.ToString();
                daoLoaiSP daolsp = new daoLoaiSP();
                int kq = daolsp.XoaLoaiSanPham(lsp);
                if (kq == 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    dgvLoaiSP.DataSource = daolsp.LayThongTinLoaiSanPham();
                }
                else
                {
                    MessageBox.Show("Quá trình thực hiện xóa thất bại, đề nghị kiểm tra lại!");
                }
                
            }

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
       
    }
}
