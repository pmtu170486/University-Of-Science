﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace DeAn
{
   public class daoLSP
    {
        connection c = new connection();
        SqlCommand comman;

        public List<dtoLSP> LayThongTinLoaiSP()
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_laythongtinLSP", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = comman.ExecuteReader();
            List<dtoLSP> List = new List<dtoLSP>();
            dtoLSP l;
            while (reader.Read())
            {
                l = new dtoLSP();
                l.MaLSP = reader["MaLSP"].ToString();
                l.TenLoai = reader["TenLoai"].ToString();
                List.Add(l);
            }
            c.CloseConnect();
            return List;

        }

        public void ThemLoaiSP(dtoLSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_themLoaiSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maLSP", System.Data.SqlDbType.NChar, 100).Value = lsp.MaLSP;
            comman.Parameters.Add("@tenLoai", System.Data.SqlDbType.NVarChar, 100).Value = lsp.TenLoai;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }

        public void CapNhatLoaiSP(dtoLSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_capnhatLoaiSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maLSP", System.Data.SqlDbType.NChar, 100).Value = lsp.MaLSP;
            comman.Parameters.Add("@tenLoai", System.Data.SqlDbType.NVarChar, 100).Value = lsp.TenLoai;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }

        public void XoaLoaiSP(dtoLSP lsp)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_xoaLoaiSanPham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@maLSP", System.Data.SqlDbType.NChar, 100).Value = lsp.MaLSP;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }
    }
}
