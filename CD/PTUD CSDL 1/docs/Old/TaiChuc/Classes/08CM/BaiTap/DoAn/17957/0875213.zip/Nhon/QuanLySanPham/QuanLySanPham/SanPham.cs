﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QuanLySanPham
{
    public partial class SanPham : Form
    {
        public int Flag = -1;
        public SanPham()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HienThiHangSanXuat()
        {
            daoHSX daohsx = new daoHSX();
            cboMaHSX.DataSource = daohsx.LayThongTinHangSanXuat();
            cboMaHSX.DisplayMember = "TenHSX";
            cboMaHSX.ValueMember = "MaHSX";

        }

        private void HienThiLoaiSanPham()
        {
            daoLoaiSP daolsp = new daoLoaiSP();
            cboMaLSP.DataSource = daolsp.LayThongTinLoaiSanPham();
            cboMaLSP.DisplayMember = "TenLoai";
            cboMaLSP.ValueMember = "MaLSP";

        }
        private void btnThemMaHSX_Click(object sender, EventArgs e)
        {
            HangSanXuat hsx = new HangSanXuat();
            hsx.ShowDialog();
            HienThiHangSanXuat();
        }

        private void btnThemMaLSP_Click(object sender, EventArgs e)
        {
            LoaiSanPham lsp = new LoaiSanPham();
            lsp.ShowDialog();
            HienThiLoaiSanPham();
        }
        private void LayDuLieuThongTinSanPham()
        {
            daoSanPham daosp = new daoSanPham();
            dgvSanPham.DataSource = daosp.LayThongTinSanPham();
        }       

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvSanPham.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }
            
            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vt = dgvSanPham.CurrentRow.Index;
                dtoSanPham sp = new dtoSanPham();
                sp.MaSP = dgvSanPham.Rows[vt].Cells[0].Value.ToString();
                daoSanPham daoSP = new daoSanPham();
                daoSP.XoaSanPham(sp);
                MessageBox.Show("Xóa thành công!");
                dgvSanPham.DataSource = daoSP.LayThongTinSanPham();
            }
        }

        private void btnThemSP_Click(object sender, EventArgs e)
        {
            if (txtMaSP.Text.Trim() == "")
            {
                MessageBox.Show("Nhập mã sản phẩm");
                txtMaSP.Focus();
                return;
            }
            if(txtTenSP.Text.Trim() == "")
            {
                MessageBox.Show("Nhập tên của sản phẩm");
                txtTenSP.Focus();
                return;
            }

            if (txtSeri.Text.Trim() == "")
            {
                MessageBox.Show("Nhập số seri của sản phẩm");
                txtSeri.Focus();
                return;
            }
           
            if (cboMaHSX.SelectedValue == null) {
                MessageBox.Show("Yêu cầu chọn hãng sản xuất của sản phẩm đang nhập liệu");
                cboMaHSX.Focus();
                return; 
            }

            if (cboMaLSP.SelectedValue == null)
            {
                MessageBox.Show("Yêu cầu chọn loại của sản phẩm đang nhập liệu");
                cboMaLSP.Focus();
                return;
            }

                
                dtoSanPham dtoSP = new dtoSanPham();
                dtoSP.MaSP = txtMaSP.Text;
                dtoSP.TenSP = txtTenSP.Text;
                dtoSP.MoTa = txtMoTa.Text;
                dtoSP.Seri = txtSeri.Text;
                dtoSP.MaHSX = cboMaHSX.SelectedValue.ToString();
                dtoSP.MaLSP = cboMaLSP.SelectedValue.ToString();

            if (Flag == 1)
            {
                
                daoSanPham daoSP = new daoSanPham();
               int kq = daoSP.ThemSanPham(dtoSP);
               if (kq == -1)
               { // thất bại, do trùng khóa chính;
                   MessageBox.Show("Trùng khóa chính rồi");
                   txtMaSP.Focus();
                   return;
               }
            }
            else 
            { 
                daoSanPham daosp = new daoSanPham();
                daosp.CapNhatSanPham(dtoSP);    
            }
            Flag = -1;
            daoSanPham DaoSanPham = new daoSanPham();
            dgvSanPham.DataSource = DaoSanPham.LayThongTinSanPham();
            dgvSanPham.Enabled = true;
            khoaGird_danhsach(false);
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnCapNhat.Visible = true;
            btnXoa.Enabled = true;
            btnThoat.Enabled = true;
            
        }
        private void dgvSanPham_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                int vitridong = dgvSanPham.CurrentRow.Index;
                txtMaSP.Text = dgvSanPham.Rows[vitridong].Cells["masp"].Value.ToString().Trim();
                txtTenSP.Text = dgvSanPham.Rows[vitridong].Cells["tensp"].Value.ToString();
                txtMoTa.Text = dgvSanPham.Rows[vitridong].Cells["mota"].Value.ToString();
                txtSeri.Text = dgvSanPham.Rows[vitridong].Cells["seri"].Value.ToString();
                cboMaHSX.SelectedValue = dgvSanPham.Rows[vitridong].Cells["mahsx"].Value.ToString();
                cboMaLSP.SelectedValue = dgvSanPham.Rows[vitridong].Cells["malsp"].Value.ToString();
            }
            catch { }
        }


        private void SanPham_Load(object sender, EventArgs e)
        {

            daoHSX daohsx = new daoHSX();   
            cboMaHSX.DataSource = daohsx.LayThongTinHangSanXuat();
            cboMaHSX.DisplayMember = "TenHSX";
            cboMaHSX.ValueMember = "MaHSX";
            HienThiHangSanXuat();
            LayDuLieuThongTinSanPham();

            daoLoaiSP daolsp = new daoLoaiSP();
            cboMaLSP.DataSource = daolsp.LayThongTinLoaiSanPham();
            cboMaLSP.DisplayMember = "TenLoai";
            cboMaLSP.ValueMember = "MaLSP";
            HienThiLoaiSanPham();
            LayDuLieuThongTinSanPham();
            khoaGird_danhsach(false);
        }

        private void khoaGird_danhsach(bool p)
        {
            txtMaSP.Enabled = p;
            txtTenSP.Enabled = p;
            txtMoTa.Enabled = p;
            txtSeri.Enabled = p;
            cboMaHSX.Enabled = p;
            cboMaLSP.Enabled = p;
            btnThemMaHSX.Enabled = p;
            btnThemMaLSP.Enabled = p;
        }

        
        private void btnboqua_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnThoat.Enabled = true;
            btnCapNhat.Visible = true;

            // áp dụng cho trường hợp thêm
            if (dgvSanPham.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }
            dgvSanPham.Enabled = true;
            try
            {
                int vitridong = dgvSanPham.CurrentRow.Index;
                txtMaSP.Text = dgvSanPham.Rows[vitridong].Cells["masp"].Value.ToString().Trim();
                txtTenSP.Text = dgvSanPham.Rows[vitridong].Cells["tensp"].Value.ToString();
                txtMoTa.Text = dgvSanPham.Rows[vitridong].Cells["mota"].Value.ToString();
                txtSeri.Text = dgvSanPham.Rows[vitridong].Cells["seri"].Value.ToString();
                cboMaHSX.SelectedValue = dgvSanPham.Rows[vitridong].Cells["mahsx"].Value.ToString();
                cboMaLSP.SelectedValue = dgvSanPham.Rows[vitridong].Cells["malsp"].Value.ToString();
            }
            catch { }
            khoaGird_danhsach(false);
            Flag = -1;

      
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;

            dgvSanPham.Enabled = false;

            txtMaSP.Text = "";
            txtTenSP.Text = "";
            txtMoTa.Text = "";
            txtSeri.Text = "";
            cboMaHSX.SelectedValue = -1;
            cboMaLSP.SelectedValue = -1;
            
            khoaGird_danhsach(true);
            Flag = 1;
            txtMaSP.Focus();

    
        }

        private void btnCapNhat_Click_1(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;
            khoaGird_danhsach(true);
            Flag = 2;// cẬP NHẬT
            txtMaSP.Focus();
        }

        

    
        
    }
}
