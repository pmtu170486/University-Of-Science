﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuanLySanPham
{
    class dtoLoaiSP
    {
        private string _maLSP;

        public string MaLSP
        {
            get { return _maLSP; }
            set { _maLSP = value; }
        }
        private string _tenLoai;

        public string TenLoai
        {
            get { return _tenLoai; }
            set { _tenLoai = value; }
        }
    }
}
