﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuanLySanPham
{
    class dtoHSX
    {
        private string _maHSX;

        public string MaHSX
        {
            get { return _maHSX; }
            set { _maHSX = value; }
        }
        private string _tenHSX;

        public string TenHSX
        {
            get { return _tenHSX; }
            set { _tenHSX = value; }
        }
        private string _maQG;

        public string MaQG
        {
            get { return _maQG; }
            set { _maQG = value; }
        }
    }
}
