﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace QLSP
{
    class DataProvider
    {
        public static OleDbConnection ConnectionData()
        {
            string cnStr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = QLSV2.mdb";
            OleDbConnection cn = new OleDbConnection(cnStr);
            cn.Open();
            return cn;
        }
        public static DataTable ExecuteQuyery(string SQL)
        {
            OleDbConnection connection = ConnectionData();

            OleDbCommand command = new OleDbCommand(SQL, connection);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            adapter.SelectCommand = command;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            connection.Close();
            return dt;

        }
        public static void ExecuteNonQuery(string sql)
        {
            OleDbConnection connection = ConnectionData();
            OleDbCommand command = new OleDbCommand(sql, connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
    }
}
