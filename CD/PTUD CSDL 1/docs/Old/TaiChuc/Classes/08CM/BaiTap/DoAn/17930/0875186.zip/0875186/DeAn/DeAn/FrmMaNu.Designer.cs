﻿namespace DeAn
{
    partial class FrmMaNu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHãngSảnXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýQuốcGiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinNhómToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinBảnQuyềnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hỗTrợTrựcTuyếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hToolStripMenuItem,
            this.thôngTinToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(661, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hToolStripMenuItem
            // 
            this.hToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýSảnPhẩmToolStripMenuItem,
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem,
            this.quảnLýHãngSảnXuấtToolStripMenuItem,
            this.quảnLýQuốcGiaToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hToolStripMenuItem.Name = "hToolStripMenuItem";
            this.hToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.hToolStripMenuItem.Text = "Hệ Thống";
            // 
            // quảnLýSảnPhẩmToolStripMenuItem
            // 
            this.quảnLýSảnPhẩmToolStripMenuItem.Name = "quảnLýSảnPhẩmToolStripMenuItem";
            this.quảnLýSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.quảnLýSảnPhẩmToolStripMenuItem.Text = "Quản Lý Sản Phẩm";
            this.quảnLýSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.quảnLýSảnPhẩmToolStripMenuItem_Click);
            // 
            // quảnLýLoạiSảnPhẩmToolStripMenuItem
            // 
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem.Name = "quảnLýLoạiSảnPhẩmToolStripMenuItem";
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem.Text = "Quản Lý Loại Sản Phẩm";
            this.quảnLýLoạiSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.quảnLýLoạiSảnPhẩmToolStripMenuItem_Click);
            // 
            // quảnLýHãngSảnXuấtToolStripMenuItem
            // 
            this.quảnLýHãngSảnXuấtToolStripMenuItem.Name = "quảnLýHãngSảnXuấtToolStripMenuItem";
            this.quảnLýHãngSảnXuấtToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.quảnLýHãngSảnXuấtToolStripMenuItem.Text = "Quản Lý Hãng Sản Xuất";
            this.quảnLýHãngSảnXuấtToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHãngSảnXuấtToolStripMenuItem_Click);
            // 
            // quảnLýQuốcGiaToolStripMenuItem
            // 
            this.quảnLýQuốcGiaToolStripMenuItem.Name = "quảnLýQuốcGiaToolStripMenuItem";
            this.quảnLýQuốcGiaToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.quảnLýQuốcGiaToolStripMenuItem.Text = "Quản Lý Quốc Gia";
            this.quảnLýQuốcGiaToolStripMenuItem.Click += new System.EventHandler(this.quảnLýQuốcGiaToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // thôngTinToolStripMenuItem
            // 
            this.thôngTinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinNhómToolStripMenuItem,
            this.thôngTinBảnQuyềnToolStripMenuItem,
            this.thoátToolStripMenuItem1});
            this.thôngTinToolStripMenuItem.Name = "thôngTinToolStripMenuItem";
            this.thôngTinToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.thôngTinToolStripMenuItem.Text = "Thông Tin";
            // 
            // thôngTinNhómToolStripMenuItem
            // 
            this.thôngTinNhómToolStripMenuItem.Name = "thôngTinNhómToolStripMenuItem";
            this.thôngTinNhómToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.thôngTinNhómToolStripMenuItem.Text = "Thông Tin Nhóm";
            this.thôngTinNhómToolStripMenuItem.Click += new System.EventHandler(this.thôngTinNhómToolStripMenuItem_Click);
            // 
            // thôngTinBảnQuyềnToolStripMenuItem
            // 
            this.thôngTinBảnQuyềnToolStripMenuItem.Name = "thôngTinBảnQuyềnToolStripMenuItem";
            this.thôngTinBảnQuyềnToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.thôngTinBảnQuyềnToolStripMenuItem.Text = "Thông Tin Bản Quyền";
            this.thôngTinBảnQuyềnToolStripMenuItem.Click += new System.EventHandler(this.thôngTinBảnQuyềnToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem1
            // 
            this.thoátToolStripMenuItem1.Name = "thoátToolStripMenuItem1";
            this.thoátToolStripMenuItem1.Size = new System.Drawing.Size(190, 22);
            this.thoátToolStripMenuItem1.Text = "Thoát";
            this.thoátToolStripMenuItem1.Click += new System.EventHandler(this.thoátToolStripMenuItem1_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hỗTrợTrựcTuyếnToolStripMenuItem,
            this.thoátToolStripMenuItem2});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ Giúp";
            // 
            // hỗTrợTrựcTuyếnToolStripMenuItem
            // 
            this.hỗTrợTrựcTuyếnToolStripMenuItem.Name = "hỗTrợTrựcTuyếnToolStripMenuItem";
            this.hỗTrợTrựcTuyếnToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.hỗTrợTrựcTuyếnToolStripMenuItem.Text = "Hỗ  Trợ Trực Tuyến";
            this.hỗTrợTrựcTuyếnToolStripMenuItem.Click += new System.EventHandler(this.hỗTrợTrựcTuyếnToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem2
            // 
            this.thoátToolStripMenuItem2.Name = "thoátToolStripMenuItem2";
            this.thoátToolStripMenuItem2.Size = new System.Drawing.Size(177, 22);
            this.thoátToolStripMenuItem2.Text = "Thoát";
            this.thoátToolStripMenuItem2.Click += new System.EventHandler(this.thoátToolStripMenuItem2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(661, 59);
            this.label1.TabIndex = 2;
            this.label1.Text = "QUẢN LÝ SẢN PHẨM";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmMaNu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 294);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMaNu";
            this.Text = "FrmMaNu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMaNu_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýLoạiSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHãngSảnXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýQuốcGiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinNhómToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinBảnQuyềnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hỗTrợTrựcTuyếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem2;
        private System.Windows.Forms.Label label1;
    }
}