﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QLSP
{
    public partial class FormChinh : Form
    {
        public FormChinh()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            QLSanPham frm = new QLSanPham();
            frm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            QLLoaiSanPham frm = new QLLoaiSanPham();
            frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            QLHangSanXuat frm = new QLHangSanXuat();
            frm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            QLQuocGia frm = new QLQuocGia();
            frm.ShowDialog();
        }

        private void FormChinh_Load(object sender, EventArgs e)
        {

        }
    }
}
