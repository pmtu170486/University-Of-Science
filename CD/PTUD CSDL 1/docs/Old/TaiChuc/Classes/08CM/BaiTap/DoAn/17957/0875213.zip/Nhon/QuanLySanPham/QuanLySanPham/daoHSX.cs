﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace QuanLySanPham
{
    class daoHSX
    {
        Connection c = new Connection();
        SqlCommand comman;

        public int ThemHangSanXuat(dtoHSX hsx)
        {
            c.OpenConnect();
            comman = new SqlCommand("ThemHangSanXuat", c.Connect);

            comman.CommandType = System.Data.CommandType.StoredProcedure;

            comman.Parameters.Add("@MaHSX", System.Data.SqlDbType.NChar, 15).Value = hsx.MaHSX;
            comman.Parameters.Add("@TenHSX", System.Data.SqlDbType.NVarChar, 50).Value = hsx.TenHSX;
            comman.Parameters.Add("@MaQG", System.Data.SqlDbType.NChar, 15).Value = hsx.MaQG;
            int kq = (int)comman.ExecuteScalar();
            c.CloseConnect();
            return kq;

        }
        public DataTable LayThongTinHangSanXuat()
        {
            c.OpenConnect();
            DataTable dt = new DataTable();
            comman = new SqlCommand("LayThongTinHangSanXuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(comman);
            adapter.Fill(dt);
            c.CloseConnect();
            return dt;
            
        }

        public int XoaHangSanXuat(dtoHSX hsx)
        { 
            c.OpenConnect();
            comman = new SqlCommand("sp_del_HSX", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaHSX", System.Data.SqlDbType.NChar, 15).Value = hsx.MaHSX;

            int kq = (int)comman.ExecuteScalar();// nhận 0: thành công ; -1 thất bại do trùng khóa
            c.CloseConnect();
            return kq;
        }

        public void CapNhatHangSanXuat(dtoHSX hsx)
        {
            c.OpenConnect();
            comman = new SqlCommand("CapNhatHangSanXuat", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;

            comman.Parameters.Add("@TenHSX", System.Data.SqlDbType.NVarChar, 50).Value = hsx.TenHSX;
            comman.Parameters.Add("@MaQG", System.Data.SqlDbType.NChar, 15).Value = hsx.MaQG;
            comman.Parameters.Add("@MaHSX", System.Data.SqlDbType.NChar, 15).Value = hsx.MaHSX;

            comman.ExecuteNonQuery();
            c.CloseConnect();
        }
        
    }
}
