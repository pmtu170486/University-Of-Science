﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuanLySanPham
{
    class dtoSanPham
    {
        private string _maSP;

        public string MaSP
        {
            get { return _maSP; }
            set { _maSP = value; }
        }

        private string _tenSP;

        public string TenSP
        {
            get { return _tenSP; }
            set { _tenSP = value; }
        }

        private string _moTa;

        public string MoTa
        {
            get { return _moTa; }
            set { _moTa = value; }
        }
        private string _seri;

        public string Seri
        {
            get { return _seri; }
            set { _seri = value; }
        }
        private string _maHSX;

        public string MaHSX
        {
            get { return _maHSX; }
            set { _maHSX = value; }
        }
        private string _maLSP;

        public string MaLSP
        {
            get { return _maLSP; }
            set { _maLSP = value; }
        }

    }
}
