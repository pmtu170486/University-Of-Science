﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DeAn
{
    public partial class frLoaiSanPham : Form
    {
        public frLoaiSanPham()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            daoLSP daoLSP = new daoLSP();
            dgvDSLSP.DataSource = daoLSP.LayThongTinLoaiSP();

        }

        private void dgvDSLSP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int vtd = dgvDSLSP.CurrentRow.Index;
            txtMaLSP.Text = dgvDSLSP.Rows[vtd].Cells[0].Value.ToString();
            txtTenLSP.Text = dgvDSLSP.Rows[vtd].Cells[1].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoLSP dtoLSP = new dtoLSP();
            dtoLSP.MaLSP = txtMaLSP.Text;
            dtoLSP.TenLoai = txtTenLSP.Text;
            daoLSP daoLSP = new daoLSP();
            daoLSP.ThemLoaiSP(dtoLSP);
            MessageBox.Show("Thêm Loại Sản Phẩm Thành Công!");
            dgvDSLSP.DataSource = daoLSP.LayThongTinLoaiSP();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            dtoLSP dtoLSP = new dtoLSP();
            dtoLSP.MaLSP = txtMaLSP.Text;
            dtoLSP.TenLoai = txtTenLSP.Text;
            daoLSP daoLSP = new daoLSP();
            daoLSP.CapNhatLoaiSP(dtoLSP);
            MessageBox.Show("Cập Nhật Loại Sản Phẩm Thành Công!");
            dgvDSLSP.DataSource = daoLSP.LayThongTinLoaiSP();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int vtd = dgvDSLSP.CurrentRow.Index;
            dtoLSP lsp = new dtoLSP();
            lsp.MaLSP = dgvDSLSP.Rows[vtd].Cells[0].Value.ToString();
            daoLSP daoLSP = new daoLSP();
            daoLSP.XoaLoaiSP(lsp);
            MessageBox.Show("Đã Xóa Loại Sản Phẩm!");
            dgvDSLSP.DataSource = daoLSP.LayThongTinLoaiSP();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
