﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace QuanLySanPham
{
    class daoQuocGia
    {
        Connection c = new Connection();
        SqlCommand comman;
        public DataTable LayThongTinQuocGia()
        {
            c.OpenConnect();
            DataTable dt = new DataTable();
            comman = new SqlCommand("LayThongTinQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(comman);
            adapter.Fill(dt);

            c.CloseConnect();
            return dt;
        }
        public int ThemQuocGia(dtoQuocGia qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("ThemQuocGia", c.Connect);

            comman.CommandType = System.Data.CommandType.StoredProcedure;

            comman.Parameters.Add("@MaQG", System.Data.SqlDbType.NChar, 15).Value = qg.MaQG;
            comman.Parameters.Add("@Ten", System.Data.SqlDbType.NVarChar, 50).Value = qg.Ten;

            
            int kq=(int)comman.ExecuteScalar(); // nhận 0: thành công ; -1 thất bại do trùng khóa
            
            c.CloseConnect();
            return kq;

        }
        public int XoaQuocGia(dtoQuocGia qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_del_QG", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaQG", System.Data.SqlDbType.NChar, 15).Value = qg.MaQG;

            int kq = (int)comman.ExecuteScalar();
            c.CloseConnect();
            return kq;
        }
        public void CapNhatQuocGia(dtoQuocGia qg)
        {
            c.OpenConnect();
            comman = new SqlCommand("CapNhatQuocGia", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            comman.Parameters.Add("@MaQG", System.Data.SqlDbType.NChar, 15).Value = qg.MaQG;
            comman.Parameters.Add("@Ten", System.Data.SqlDbType.NVarChar, 50).Value = qg.Ten;
            comman.ExecuteNonQuery();
            c.CloseConnect();
        }

    }
}
