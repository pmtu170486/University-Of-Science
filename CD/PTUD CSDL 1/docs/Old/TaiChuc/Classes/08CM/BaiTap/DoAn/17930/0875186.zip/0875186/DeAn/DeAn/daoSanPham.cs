﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace DeAn
{
    public class daoSanPham
    {
        connection c = new connection();
        SqlCommand comman;

        public List<dtoSanPham> XemDanhSachSanPham()
        {
            c.OpenConnect();
            comman = new SqlCommand("sp_laythongtinsanpham", c.Connect);
            comman.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = comman.ExecuteReader();
            List<dtoSanPham> l = new List<dtoSanPham>();
            dtoSanPham sp;

            while (reader.Read())
            {

                sp = new dtoSanPham();
                sp.MaSP = reader["MaSP"].ToString();
                sp.TenSP = reader["TenSP"].ToString();
                sp.MoTa = reader["MoTa"].ToString();
                sp.SeRi = reader["SeRi"].ToString();
                sp.MaHSX = reader["MaHSX"].ToString();
                sp.LoaiSP = reader["MaLSP"].ToString();

                l.Add(sp);
            }
            c.CloseConnect();
            return l;
        }


       public void ThemSanPham(dtoSanPham sp)
       {
           c.OpenConnect();
           comman = new SqlCommand("sp_themsanpham", c.Connect);
           comman.CommandType = System.Data.CommandType.StoredProcedure;
           comman.Parameters.Add("@masp", System.Data.SqlDbType.NChar, 100).Value = sp.MaSP;
           comman.Parameters.Add("@tensp", System.Data.SqlDbType.NVarChar, 100).Value = sp.TenSP;
           comman.Parameters.Add("@mota", System.Data.SqlDbType.NVarChar, 100).Value = sp.MoTa;
           comman.Parameters.Add("@seri", System.Data.SqlDbType.Char, 100).Value = sp.SeRi;
           comman.Parameters.Add("@mahsx", System.Data.SqlDbType.NChar, 100).Value = sp.MaHSX;
           comman.Parameters.Add("@malsp", System.Data.SqlDbType.NChar, 100).Value = sp.LoaiSP;
           comman.ExecuteNonQuery();
           c.CloseConnect();
       }

       public void CapNhatSanPham(dtoSanPham sp)
       {
           c.OpenConnect();
           comman = new SqlCommand("sp_capnhatsanpham", c.Connect);
           comman.CommandType = System.Data.CommandType.StoredProcedure;
           comman.Parameters.Add("@masp", System.Data.SqlDbType.NChar, 100).Value = sp.MaSP;
           comman.Parameters.Add("@tensp", System.Data.SqlDbType.NVarChar, 100).Value = sp.TenSP;
           comman.Parameters.Add("@mota", System.Data.SqlDbType.NVarChar, 100).Value = sp.MoTa;
           comman.Parameters.Add("@seri", System.Data.SqlDbType.Char, 100).Value = sp.SeRi;
           comman.Parameters.Add("@mahsx", System.Data.SqlDbType.NChar, 100).Value = sp.MaHSX;
           comman.Parameters.Add("@malsp", System.Data.SqlDbType.NChar, 100).Value = sp.LoaiSP;
           comman.ExecuteNonQuery();
           c.CloseConnect();
       }

       public void XoaSanPham(dtoSanPham sp)
       {
           c.OpenConnect();
           comman = new SqlCommand("sp_xoasanpham", c.Connect);
           comman.CommandType = System.Data.CommandType.StoredProcedure;
           comman.Parameters.Add("@masp", System.Data.SqlDbType.NChar,100).Value = sp.MaSP;
           comman.ExecuteNonQuery();
           c.CloseConnect();

       }


    }
}
