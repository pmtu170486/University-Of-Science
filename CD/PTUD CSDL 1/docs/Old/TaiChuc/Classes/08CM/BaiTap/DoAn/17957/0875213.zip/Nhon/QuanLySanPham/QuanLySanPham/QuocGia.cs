﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QuanLySanPham
{
    public partial class QuocGia : Form
    {
        public int Flag = -1;
        public QuocGia()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
        
        private void LayThongTinQuocGia()
        {
            daoQuocGia daoqg = new daoQuocGia();
            dgvQuocGia.DataSource = daoqg.LayThongTinQuocGia();
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            dtoQuocGia dtoqg  = new dtoQuocGia();
            dtoqg.MaQG = txtMaQG.Text;
            dtoqg.Ten = txtTenQG.Text; 
            daoQuocGia daoqg = new daoQuocGia();
            daoqg.ThemQuocGia(dtoqg);
            MessageBox.Show("Thêm quốc gia thành công !");

            LayThongTinQuocGia();
        }

        private void QuocGia_Load(object sender, EventArgs e)
        {
            LayThongTinQuocGia();
            khoaGird_danhsach(false);
        }

        private void khoaGird_danhsach(bool p)
        {
            txtMaQG.Enabled = p;
            txtTenQG.Enabled = p;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vitrixoa = dgvQuocGia.CurrentRow.Index;
                dtoQuocGia qg = new dtoQuocGia();
                qg.MaQG = dgvQuocGia.Rows[vitrixoa].Cells[0].Value.ToString();
                daoQuocGia daoqg = new daoQuocGia();
                daoqg.XoaQuocGia(qg);
                MessageBox.Show("Xóa thành công!");
                dgvQuocGia.DataSource = daoqg.LayThongTinQuocGia();
            } 
            
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaQG.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập mã quốc gia !");
                txtMaQG.Focus();
                return;
            }

            if (txtTenQG.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập tên quốc gia !");
                txtTenQG.Focus();
                return;
            }
            
            dtoQuocGia dtoqg = new dtoQuocGia();
            dtoqg.MaQG = txtMaQG.Text;
            dtoqg.Ten  = txtTenQG.Text;

            if (Flag == 1)// thêm mới
            {
                daoQuocGia daoqg = new daoQuocGia();
                int kq=daoqg.ThemQuocGia(dtoqg);
                if (kq == -1) { // thất bại, do trùng khóa chính;
                    MessageBox.Show("Trùng khóa chính rồi");
                    txtMaQG.Focus();
                    return;
                }
            }
            else
            {
                daoQuocGia daoqg = new daoQuocGia();
                daoqg.CapNhatQuocGia(dtoqg);
            }
            Flag = -1;
            daoQuocGia daoQG = new daoQuocGia();
            dgvQuocGia.DataSource = daoQG.LayThongTinQuocGia();

            dgvQuocGia.Enabled = true;
            khoaGird_danhsach(false);
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnCapNhat.Visible = true;
            btnXoa.Enabled = true;
            btnThoat.Enabled = true;

        
        }

        private void dgvQuocGia_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                int vitridong = dgvQuocGia.CurrentRow.Index;
                txtMaQG.Text = dgvQuocGia.Rows[vitridong].Cells["maqg"].Value.ToString().Trim();
                txtTenQG.Text = dgvQuocGia.Rows[vitridong].Cells["ten"].Value.ToString();
            }
            catch { }
        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = false;
            btnThem.Visible = true;
            btnboqua.Visible = false;
            btnThoat.Enabled = true;
            btnCapNhat.Visible = true;

            if (dgvQuocGia.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }
            dgvQuocGia.Enabled = true;
            try
            {
                int vitridong = dgvQuocGia.CurrentRow.Index;
                txtMaQG.Text = dgvQuocGia.Rows[vitridong].Cells["maqg"].Value.ToString();
                txtTenQG.Text = dgvQuocGia.Rows[vitridong].Cells["ten"].Value.ToString();
            }
            catch { }
            khoaGird_danhsach(false);
            Flag = -1;

        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;
            khoaGird_danhsach(true);
            Flag = 2;
            txtMaQG.Focus();
        }

        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (dgvQuocGia.Rows.Count != 0)
            {
                btnXoa.Enabled = true;
                btnCapNhat.Enabled = true;
            }
            else
            {
                btnXoa.Enabled = false;
                btnCapNhat.Enabled = false;
            }

            DialogResult dr = MessageBox.Show("Bạn có muốn xóa không?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dr == DialogResult.Yes)
            {
                int vt = dgvQuocGia.CurrentRow.Index;
                dtoQuocGia qg = new dtoQuocGia();
                qg.MaQG = dgvQuocGia.Rows[vt].Cells[0].Value.ToString();
                daoQuocGia daoqg = new daoQuocGia();
                int kq=daoqg.XoaQuocGia(qg);
                if (kq == 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    dgvQuocGia.DataSource = daoqg.LayThongTinQuocGia();
                }
                else {
                    MessageBox.Show("Quá trình thực hiện xóa thất bại, đề nghị kiểm tra lại!");
                }
            }

        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            btnLuu.Visible = true;
            btnThem.Visible = false;
            btnboqua.Visible = true;
            btnCapNhat.Visible = false;
            btnXoa.Enabled = false;
            btnThoat.Enabled = false;

            dgvQuocGia.Enabled = false;

            txtMaQG.Text = "";
            txtTenQG.Text = "";
            khoaGird_danhsach(true);
            Flag = 1;
            txtMaQG.Focus();
        }

        
    }
}
