﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeAn
{
   public class dtoLSP
    {
        private string maLSP;

        public string MaLSP
        {
            get { return maLSP; }
            set { maLSP = value; }
        }
        private string tenLoai;

        public string TenLoai
        {
            get { return tenLoai; }
            set { tenLoai = value; }
        }
    }
}
