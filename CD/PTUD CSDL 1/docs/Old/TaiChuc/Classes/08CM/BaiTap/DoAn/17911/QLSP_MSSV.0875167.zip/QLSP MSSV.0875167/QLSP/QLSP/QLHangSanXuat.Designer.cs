﻿namespace QLSP
{
    partial class QLHangSanXuat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnThemHangSanXuat = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dgvDSHSX = new System.Windows.Forms.DataGridView();
            this.txtTenHSX = new System.Windows.Forms.TextBox();
            this.cbx_QuocGia = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHSX)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(245, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hãng Sản Xuất";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên HSX";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(97, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mã QG";
            // 
            // btnThemHangSanXuat
            // 
            this.btnThemHangSanXuat.Location = new System.Drawing.Point(172, 225);
            this.btnThemHangSanXuat.Name = "btnThemHangSanXuat";
            this.btnThemHangSanXuat.Size = new System.Drawing.Size(123, 23);
            this.btnThemHangSanXuat.TabIndex = 7;
            this.btnThemHangSanXuat.Text = "Thêm Hãng Sản Xuất";
            this.btnThemHangSanXuat.UseVisualStyleBackColor = true;
            this.btnThemHangSanXuat.Click += new System.EventHandler(this.btnThemHangSanXuat_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(343, 225);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(75, 23);
            this.btnCapNhat.TabIndex = 8;
            this.btnCapNhat.Text = "Cập Nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(467, 225);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 23);
            this.btnXoa.TabIndex = 9;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // dgvDSHSX
            // 
            this.dgvDSHSX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSHSX.Location = new System.Drawing.Point(115, 276);
            this.dgvDSHSX.Name = "dgvDSHSX";
            this.dgvDSHSX.Size = new System.Drawing.Size(442, 150);
            this.dgvDSHSX.TabIndex = 10;
            // 
            // txtTenHSX
            // 
            this.txtTenHSX.Location = new System.Drawing.Point(205, 63);
            this.txtTenHSX.Name = "txtTenHSX";
            this.txtTenHSX.Size = new System.Drawing.Size(337, 20);
            this.txtTenHSX.TabIndex = 12;
            // 
            // cbx_QuocGia
            // 
            this.cbx_QuocGia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_QuocGia.FormattingEnabled = true;
            this.cbx_QuocGia.Location = new System.Drawing.Point(204, 117);
            this.cbx_QuocGia.Name = "cbx_QuocGia";
            this.cbx_QuocGia.Size = new System.Drawing.Size(338, 21);
            this.cbx_QuocGia.TabIndex = 13;
            // 
            // QLHangSanXuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 461);
            this.Controls.Add(this.cbx_QuocGia);
            this.Controls.Add(this.txtTenHSX);
            this.Controls.Add(this.dgvDSHSX);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnCapNhat);
            this.Controls.Add(this.btnThemHangSanXuat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "QLHangSanXuat";
            this.Text = "QLHangSanXuat";
            this.Load += new System.EventHandler(this.QLHangSanXuat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHSX)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnThemHangSanXuat;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.DataGridView dgvDSHSX;
        private System.Windows.Forms.TextBox txtTenHSX;
        private System.Windows.Forms.ComboBox cbx_QuocGia;

    }
}