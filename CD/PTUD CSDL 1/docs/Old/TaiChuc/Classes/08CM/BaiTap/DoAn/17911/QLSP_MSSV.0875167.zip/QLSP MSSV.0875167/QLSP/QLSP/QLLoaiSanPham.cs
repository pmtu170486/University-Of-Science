﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace QLSP
{
    public partial class QLLoaiSanPham : Form
    {
        public QLLoaiSanPham()
        {
            InitializeComponent();
        }
        private void QLLoaiSanPham_Load(object sender, EventArgs e)
        {
            LoaiSanPham lsp = new LoaiSanPham();
            dgvDSLSP.DataSource = lsp.LayDanhSach();
        }

        private void btnThemLoaiSanPham_Click(object sender, EventArgs e)
        {
            if (txtTenLoai.Text == "")
            {
                MessageBox.Show("Nhập tên Loại Sản Phẩm");
                return;
            }
            LoaiSanPham qg = new LoaiSanPham();
            qg.Them(txtTenLoai.Text);

            dgvDSLSP.DataSource = qg.LayDanhSach();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDSLSP.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvDSLSP.SelectedRows[0];
                if (!row.IsNewRow)
                {
                    int id = Convert.ToInt32(row.Cells[0].Value);
                    string thongbao = "ban co muon xoa  " + id;
                    if (MessageBox.Show(
                        thongbao,
                        "XacNhan",
                        MessageBoxButtons.YesNo
                        ) ==
                        DialogResult.Yes)
                    {
                        LoaiSanPham qg = new LoaiSanPham();
                        qg.Xoa(id);
                        dgvDSLSP.DataSource = qg.LayDanhSach();

                    }
                }
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {

            LoaiSanPham lsp = new LoaiSanPham();
            lsp.LayDanhSach();
            MessageBox.Show("Cap Nhat Thành Công");
        }
    }
}
