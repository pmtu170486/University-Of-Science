﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeAn
{
   public class dtoSanPham
    {
        private string maSP;

        public string MaSP
        {
            get { return maSP; }
            set { maSP = value; }
        }
        private string tenSP;

        public string TenSP
        {
            get { return tenSP; }
            set { tenSP = value; }
        }
        private string moTa;

        public string MoTa
        {
            get { return moTa; }
            set { moTa = value; }
        }
        private string seRi;

        public string SeRi
        {
            get { return seRi; }
            set { seRi = value; }
        }
        private string maHSX;

        public string MaHSX
        {
            get { return maHSX; }
            set { maHSX = value; }
        }
        private string loaiSP;

        public string LoaiSP
        {
            get { return loaiSP; }
            set { loaiSP = value; }
        }

    }
}
