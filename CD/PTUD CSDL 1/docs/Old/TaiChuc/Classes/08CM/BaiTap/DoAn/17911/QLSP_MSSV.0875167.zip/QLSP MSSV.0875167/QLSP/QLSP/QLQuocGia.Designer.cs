﻿namespace QLSP
{
    partial class QLQuocGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.dgvDSQG = new System.Windows.Forms.DataGridView();
            this.btnThemQuocGia = new System.Windows.Forms.Button();
            this.btnCapNhatQuocGia = new System.Windows.Forms.Button();
            this.btnXoaQuocGia = new System.Windows.Forms.Button();
            this.txtTenQG = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSQG)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(117, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên QG";
            // 
            // dgvDSQG
            // 
            this.dgvDSQG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSQG.Location = new System.Drawing.Point(116, 156);
            this.dgvDSQG.Name = "dgvDSQG";
            this.dgvDSQG.Size = new System.Drawing.Size(402, 205);
            this.dgvDSQG.TabIndex = 4;
            // 
            // btnThemQuocGia
            // 
            this.btnThemQuocGia.Location = new System.Drawing.Point(116, 72);
            this.btnThemQuocGia.Name = "btnThemQuocGia";
            this.btnThemQuocGia.Size = new System.Drawing.Size(106, 23);
            this.btnThemQuocGia.TabIndex = 5;
            this.btnThemQuocGia.Text = "Thêm Quốc Gia";
            this.btnThemQuocGia.UseVisualStyleBackColor = true;
            this.btnThemQuocGia.Click += new System.EventHandler(this.btnThemQuocGia_Click);
            // 
            // btnCapNhatQuocGia
            // 
            this.btnCapNhatQuocGia.Location = new System.Drawing.Point(212, 384);
            this.btnCapNhatQuocGia.Name = "btnCapNhatQuocGia";
            this.btnCapNhatQuocGia.Size = new System.Drawing.Size(75, 23);
            this.btnCapNhatQuocGia.TabIndex = 6;
            this.btnCapNhatQuocGia.Text = "Cập Nhật ";
            this.btnCapNhatQuocGia.UseVisualStyleBackColor = true;
            this.btnCapNhatQuocGia.Click += new System.EventHandler(this.btnCapNhatQuocGia_Click);
            // 
            // btnXoaQuocGia
            // 
            this.btnXoaQuocGia.Location = new System.Drawing.Point(334, 384);
            this.btnXoaQuocGia.Name = "btnXoaQuocGia";
            this.btnXoaQuocGia.Size = new System.Drawing.Size(75, 23);
            this.btnXoaQuocGia.TabIndex = 7;
            this.btnXoaQuocGia.Text = "Xóa";
            this.btnXoaQuocGia.UseVisualStyleBackColor = true;
            this.btnXoaQuocGia.Click += new System.EventHandler(this.btnXoaQuocGia_Click);
            // 
            // txtTenQG
            // 
            this.txtTenQG.Location = new System.Drawing.Point(212, 36);
            this.txtTenQG.Name = "txtTenQG";
            this.txtTenQG.Size = new System.Drawing.Size(100, 20);
            this.txtTenQG.TabIndex = 8;
            // 
            // QLQuocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 450);
            this.Controls.Add(this.txtTenQG);
            this.Controls.Add(this.btnXoaQuocGia);
            this.Controls.Add(this.btnCapNhatQuocGia);
            this.Controls.Add(this.btnThemQuocGia);
            this.Controls.Add(this.dgvDSQG);
            this.Controls.Add(this.label2);
            this.Name = "QLQuocGia";
            this.Text = "QLQuocGia";
            this.Load += new System.EventHandler(this.QLQuocGia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSQG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDSQG;
        private System.Windows.Forms.Button btnThemQuocGia;
        private System.Windows.Forms.Button btnCapNhatQuocGia;
        private System.Windows.Forms.Button btnXoaQuocGia;
        private System.Windows.Forms.TextBox txtTenQG;
    }
}