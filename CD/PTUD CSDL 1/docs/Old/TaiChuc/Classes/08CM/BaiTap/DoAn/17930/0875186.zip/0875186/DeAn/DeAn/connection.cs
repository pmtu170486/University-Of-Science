﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace DeAn
{
   public class connection
    {
        private string _connectionString;

        public string ConnectionString
        {
            get { return _connectionString; }
            set { _connectionString = value; }
        }

        private SqlConnection connect;

        public SqlConnection Connect
        {
            get { return connect; }
            set { connect = value; }
        }
        public connection()
        {
            ConnectionString = "Data Source=Love_Me-PC;Initial Catalog=QuanLySanPham;Integrated Security=True";
            connect = new SqlConnection(ConnectionString);
        }
        public void OpenConnect()
        {
            connect.Open();

        }
        public void CloseConnect()
        {
            connect.Close();


        }
    }
}
